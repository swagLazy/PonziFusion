# 庞氏骗局智能合约数据集
## 简介
包含从Etherscan上爬取并人工标注的6,498个庞氏骗局智能合约数据集
## 更新时间
数据集中智能合约的发布时间为0~7,500,000区块高度
## 数据集内容
| 列 | 内容|
| --- | --- |
| address| 智能合约地址 |
| opcode| 经转译后不包含操作数的智能合约操作码| 
| code|  智能合约源代码| 
| contractCode|  智能合约字节码| 
| createdBlockNumber|  智能合约创建时区块高度| 
| createdTransactionHash|  智能合约创建时交易哈希| 
| creationCode| 智能合约创建时的creation code| 
| creator|  智能合约发布者| 
| label|  智能合约是否为庞氏骗局合约（人工标注）| 

## 联系
zhongzhj3@mail2.sysu.edu.cn