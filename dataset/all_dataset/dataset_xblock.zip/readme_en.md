## Name
Ponzi Contract Dataset
## Description
The Dataset contains 6,498 smart contracts on Ethereum, 318 of which are mannually labeled as Ponzi contracts and the rest are mannually labeld as non-Ponzi contracts. The source code of these smart contracts are crawled from ehterscan.io.
## Update Log
The smart contracts in this dataset is created within height 0 to 7,500,000 (Ethereum blockheight).
## Contents
| columns | content|
| --- | --- |
| address|  address of the smart contract |
| opcode| disassembled opcode of the smart contract bytecode (discarding opcode number)| 
| code|  source code of the smart contract| 
| contractCode| bytecode of the smart contract| 
| createdBlockNumber| Ethereum blockheight when the smart contract was created| 
| createdTransactionHash|  creation transaction hash of the smart contract| 
| creationCode| creation code when creating the smart contract| 
| creator| creator of the smart contract| 
| label|  whether the smart contract is Ponzi contract (mannually labeld). 1 for Ponzi contract and 0 for non-Ponzi contract| 
## Contact
Please contact zhijie (zhongzhj3@mail2.sysu.edu.cn) for any questions about the dataset. 
